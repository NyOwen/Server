gdjs.P2GameCode = {};
gdjs.P2GameCode.localVariables = [];
gdjs.P2GameCode.GDGreenFlatBarObjects1_1final = [];

gdjs.P2GameCode.GDOrangeFlatBarObjects1_1final = [];

gdjs.P2GameCode.GDPlayer1Objects1= [];
gdjs.P2GameCode.GDPlayer1Objects2= [];
gdjs.P2GameCode.GDPlayer1Objects3= [];
gdjs.P2GameCode.GDPlatform0Objects1= [];
gdjs.P2GameCode.GDPlatform0Objects2= [];
gdjs.P2GameCode.GDPlatform0Objects3= [];
gdjs.P2GameCode.GDSideObjects1= [];
gdjs.P2GameCode.GDSideObjects2= [];
gdjs.P2GameCode.GDSideObjects3= [];
gdjs.P2GameCode.GDPlatform1Objects1= [];
gdjs.P2GameCode.GDPlatform1Objects2= [];
gdjs.P2GameCode.GDPlatform1Objects3= [];
gdjs.P2GameCode.GDTImeUIObjects1= [];
gdjs.P2GameCode.GDTImeUIObjects2= [];
gdjs.P2GameCode.GDTImeUIObjects3= [];
gdjs.P2GameCode.GDSpeedObjects1= [];
gdjs.P2GameCode.GDSpeedObjects2= [];
gdjs.P2GameCode.GDSpeedObjects3= [];
gdjs.P2GameCode.GDGreenFlatBarObjects1= [];
gdjs.P2GameCode.GDGreenFlatBarObjects2= [];
gdjs.P2GameCode.GDGreenFlatBarObjects3= [];
gdjs.P2GameCode.GD_95951PsHPObjects1= [];
gdjs.P2GameCode.GD_95951PsHPObjects2= [];
gdjs.P2GameCode.GD_95951PsHPObjects3= [];
gdjs.P2GameCode.GDOrangeFlatBarObjects1= [];
gdjs.P2GameCode.GDOrangeFlatBarObjects2= [];
gdjs.P2GameCode.GDOrangeFlatBarObjects3= [];
gdjs.P2GameCode.GDUpperformObjects1= [];
gdjs.P2GameCode.GDUpperformObjects2= [];
gdjs.P2GameCode.GDUpperformObjects3= [];
gdjs.P2GameCode.GDItem0Objects1= [];
gdjs.P2GameCode.GDItem0Objects2= [];
gdjs.P2GameCode.GDItem0Objects3= [];
gdjs.P2GameCode.GDExplosion1Objects1= [];
gdjs.P2GameCode.GDExplosion1Objects2= [];
gdjs.P2GameCode.GDExplosion1Objects3= [];
gdjs.P2GameCode.GDPlatform2Objects1= [];
gdjs.P2GameCode.GDPlatform2Objects2= [];
gdjs.P2GameCode.GDPlatform2Objects3= [];
gdjs.P2GameCode.GDPlatform3Objects1= [];
gdjs.P2GameCode.GDPlatform3Objects2= [];
gdjs.P2GameCode.GDPlatform3Objects3= [];
gdjs.P2GameCode.GDPlayer2Objects1= [];
gdjs.P2GameCode.GDPlayer2Objects2= [];
gdjs.P2GameCode.GDPlayer2Objects3= [];
gdjs.P2GameCode.GD_95952PsHPObjects1= [];
gdjs.P2GameCode.GD_95952PsHPObjects2= [];
gdjs.P2GameCode.GD_95952PsHPObjects3= [];
gdjs.P2GameCode.GDScore2Objects1= [];
gdjs.P2GameCode.GDScore2Objects2= [];
gdjs.P2GameCode.GDScore2Objects3= [];
gdjs.P2GameCode.GDScore1Objects1= [];
gdjs.P2GameCode.GDScore1Objects2= [];
gdjs.P2GameCode.GDScore1Objects3= [];
gdjs.P2GameCode.GDP1scoreObjects1= [];
gdjs.P2GameCode.GDP1scoreObjects2= [];
gdjs.P2GameCode.GDP1scoreObjects3= [];
gdjs.P2GameCode.GDP2scoreObjects1= [];
gdjs.P2GameCode.GDP2scoreObjects2= [];
gdjs.P2GameCode.GDP2scoreObjects3= [];
gdjs.P2GameCode.GDPlatform4Objects1= [];
gdjs.P2GameCode.GDPlatform4Objects2= [];
gdjs.P2GameCode.GDPlatform4Objects3= [];
gdjs.P2GameCode.GDItem1Objects1= [];
gdjs.P2GameCode.GDItem1Objects2= [];
gdjs.P2GameCode.GDItem1Objects3= [];
gdjs.P2GameCode.GDItem2Objects1= [];
gdjs.P2GameCode.GDItem2Objects2= [];
gdjs.P2GameCode.GDItem2Objects3= [];
gdjs.P2GameCode.GDItem3Objects1= [];
gdjs.P2GameCode.GDItem3Objects2= [];
gdjs.P2GameCode.GDItem3Objects3= [];
gdjs.P2GameCode.GDBackgroundObjects1= [];
gdjs.P2GameCode.GDBackgroundObjects2= [];
gdjs.P2GameCode.GDBackgroundObjects3= [];


gdjs.P2GameCode.asyncCallback14447324 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.P2GameCode.localVariables);
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}gdjs.P2GameCode.localVariables.length = 0;
}
gdjs.P2GameCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.P2GameCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.P2GameCode.asyncCallback14447324(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.P2GameCode.asyncCallback14448932 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.P2GameCode.localVariables);
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}gdjs.P2GameCode.localVariables.length = 0;
}
gdjs.P2GameCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.P2GameCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.P2GameCode.asyncCallback14448932(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.P2GameCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.P2GameCode.GDGreenFlatBarObjects1, gdjs.P2GameCode.GDGreenFlatBarObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDGreenFlatBarObjects2.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDGreenFlatBarObjects2[i].IsEmpty((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDGreenFlatBarObjects2[k] = gdjs.P2GameCode.GDGreenFlatBarObjects2[i];
        ++k;
    }
}
gdjs.P2GameCode.GDGreenFlatBarObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14446388);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects2);
gdjs.copyArray(runtimeScene.getObjects("TImeUI"), gdjs.P2GameCode.GDTImeUIObjects2);
{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects2.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects2[i].getBehavior("Animation").setAnimationName("Dead");
}
}{for(var i = 0, len = gdjs.P2GameCode.GDTImeUIObjects2.length ;i < len;++i) {
    gdjs.P2GameCode.GDTImeUIObjects2[i].getBehavior("Text").setText("2P WIN");
}
}{runtimeScene.getGame().getVariables().getFromIndex(10).add(1);
}
{ //Subevents
gdjs.P2GameCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.P2GameCode.GDOrangeFlatBarObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDOrangeFlatBarObjects1.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDOrangeFlatBarObjects1[i].IsEmpty((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDOrangeFlatBarObjects1[k] = gdjs.P2GameCode.GDOrangeFlatBarObjects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDOrangeFlatBarObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14447996);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects1);
gdjs.copyArray(runtimeScene.getObjects("TImeUI"), gdjs.P2GameCode.GDTImeUIObjects1);
{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("Animation").setAnimationName("Dead");
}
}{for(var i = 0, len = gdjs.P2GameCode.GDTImeUIObjects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDTImeUIObjects1[i].getBehavior("Text").setText("1P WIN");
}
}{runtimeScene.getGame().getVariables().getFromIndex(9).add(1);
}
{ //Subevents
gdjs.P2GameCode.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.P2GameCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.P2GameCode.GDPlayer1Objects1, gdjs.P2GameCode.GDPlayer1Objects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDPlayer1Objects2.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDPlayer1Objects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDPlayer1Objects2[k] = gdjs.P2GameCode.GDPlayer1Objects2[i];
        ++k;
    }
}
gdjs.P2GameCode.GDPlayer1Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDPlayer1Objects2 */
{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects2.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects2[i].getBehavior("Animation").setAnimationName("Run");
}
}}

}


{

/* Reuse gdjs.P2GameCode.GDPlayer1Objects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDPlayer1Objects1.length;i<l;++i) {
    if ( !(gdjs.P2GameCode.GDPlayer1Objects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDPlayer1Objects1[k] = gdjs.P2GameCode.GDPlayer1Objects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDPlayer1Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDPlayer1Objects1 */
{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects1[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


};gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects = Hashtable.newFrom({"Player1": gdjs.P2GameCode.GDPlayer1Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform0Objects1Objects = Hashtable.newFrom({"Platform0": gdjs.P2GameCode.GDPlatform0Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects = Hashtable.newFrom({"Player1": gdjs.P2GameCode.GDPlayer1Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform1Objects1Objects = Hashtable.newFrom({"Platform1": gdjs.P2GameCode.GDPlatform1Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects = Hashtable.newFrom({"Player1": gdjs.P2GameCode.GDPlayer1Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform2Objects1Objects = Hashtable.newFrom({"Platform2": gdjs.P2GameCode.GDPlatform2Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects = Hashtable.newFrom({"Player1": gdjs.P2GameCode.GDPlayer1Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform3Objects1Objects = Hashtable.newFrom({"Platform3": gdjs.P2GameCode.GDPlatform3Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects = Hashtable.newFrom({"Player1": gdjs.P2GameCode.GDPlayer1Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform4Objects1Objects = Hashtable.newFrom({"Platform4": gdjs.P2GameCode.GDPlatform4Objects1});
gdjs.P2GameCode.asyncCallback14458988 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.P2GameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects2);

{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects2.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects2[i].getBehavior("PlatformerObject").setJumpSpeed(0);
}
}gdjs.P2GameCode.localVariables.length = 0;
}
gdjs.P2GameCode.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.P2GameCode.localVariables);
for (const obj of gdjs.P2GameCode.GDPlayer1Objects1) asyncObjectsList.addObject("Player1", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.P2GameCode.asyncCallback14458988(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects = Hashtable.newFrom({"Player1": gdjs.P2GameCode.GDPlayer1Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDUpperformObjects1Objects = Hashtable.newFrom({"Upperform": gdjs.P2GameCode.GDUpperformObjects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects = Hashtable.newFrom({"Player1": gdjs.P2GameCode.GDPlayer1Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDItem0Objects1Objects = Hashtable.newFrom({"Item0": gdjs.P2GameCode.GDItem0Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDExplosion1Objects1Objects = Hashtable.newFrom({"Explosion1": gdjs.P2GameCode.GDExplosion1Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects = Hashtable.newFrom({"Player1": gdjs.P2GameCode.GDPlayer1Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDItem1Objects1Objects = Hashtable.newFrom({"Item1": gdjs.P2GameCode.GDItem1Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDExplosion1Objects1Objects = Hashtable.newFrom({"Explosion1": gdjs.P2GameCode.GDExplosion1Objects1});
gdjs.P2GameCode.asyncCallback14463180 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.P2GameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects2);

{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects2.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects2[i].getBehavior("PlatformerObject").setMaxSpeed(500);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects2.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects2[i].getBehavior("PlatformerObject").setAcceleration(2000);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects2.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects2[i].getBehavior("PlatformerObject").setDeceleration(2000);
}
}gdjs.P2GameCode.localVariables.length = 0;
}
gdjs.P2GameCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.P2GameCode.localVariables);
for (const obj of gdjs.P2GameCode.GDPlayer1Objects1) asyncObjectsList.addObject("Player1", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.P2GameCode.asyncCallback14463180(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects = Hashtable.newFrom({"Player1": gdjs.P2GameCode.GDPlayer1Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDItem2Objects1Objects = Hashtable.newFrom({"Item2": gdjs.P2GameCode.GDItem2Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDExplosion1Objects1Objects = Hashtable.newFrom({"Explosion1": gdjs.P2GameCode.GDExplosion1Objects1});
gdjs.P2GameCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber() < 1);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(1);
}}

}


};gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects = Hashtable.newFrom({"Player1": gdjs.P2GameCode.GDPlayer1Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDItem3Objects1Objects = Hashtable.newFrom({"Item3": gdjs.P2GameCode.GDItem3Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDExplosion1Objects1Objects = Hashtable.newFrom({"Explosion1": gdjs.P2GameCode.GDExplosion1Objects1});
gdjs.P2GameCode.asyncCallback14334140 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.P2GameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects2);

{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects2.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects2[i].getBehavior("PlatformerObject").setMaxSpeed(500);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects2.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects2[i].getBehavior("PlatformerObject").setAcceleration(2000);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects2.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects2[i].getBehavior("PlatformerObject").setDeceleration(2000);
}
}gdjs.P2GameCode.localVariables.length = 0;
}
gdjs.P2GameCode.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.P2GameCode.localVariables);
for (const obj of gdjs.P2GameCode.GDPlayer1Objects1) asyncObjectsList.addObject("Player1", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.P2GameCode.asyncCallback14334140(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.P2GameCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.P2GameCode.GDPlayer2Objects1, gdjs.P2GameCode.GDPlayer2Objects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDPlayer2Objects2.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDPlayer2Objects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDPlayer2Objects2[k] = gdjs.P2GameCode.GDPlayer2Objects2[i];
        ++k;
    }
}
gdjs.P2GameCode.GDPlayer2Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDPlayer2Objects2 */
{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects2.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects2[i].getBehavior("Animation").setAnimationName("Run");
}
}}

}


{

/* Reuse gdjs.P2GameCode.GDPlayer2Objects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDPlayer2Objects1.length;i<l;++i) {
    if ( !(gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDPlayer2Objects1[k] = gdjs.P2GameCode.GDPlayer2Objects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDPlayer2Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDPlayer2Objects1 */
{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


};gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player2": gdjs.P2GameCode.GDPlayer2Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform0Objects1Objects = Hashtable.newFrom({"Platform0": gdjs.P2GameCode.GDPlatform0Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player2": gdjs.P2GameCode.GDPlayer2Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform1Objects1Objects = Hashtable.newFrom({"Platform1": gdjs.P2GameCode.GDPlatform1Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player2": gdjs.P2GameCode.GDPlayer2Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform2Objects1Objects = Hashtable.newFrom({"Platform2": gdjs.P2GameCode.GDPlatform2Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player2": gdjs.P2GameCode.GDPlayer2Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform3Objects1Objects = Hashtable.newFrom({"Platform3": gdjs.P2GameCode.GDPlatform3Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player2": gdjs.P2GameCode.GDPlayer2Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform4Objects1Objects = Hashtable.newFrom({"Platform4": gdjs.P2GameCode.GDPlatform4Objects1});
gdjs.P2GameCode.asyncCallback14476308 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.P2GameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects2);

{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects2.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects2[i].getBehavior("PlatformerObject").setJumpSpeed(0);
}
}gdjs.P2GameCode.localVariables.length = 0;
}
gdjs.P2GameCode.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.P2GameCode.localVariables);
for (const obj of gdjs.P2GameCode.GDPlayer2Objects1) asyncObjectsList.addObject("Player2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.P2GameCode.asyncCallback14476308(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player2": gdjs.P2GameCode.GDPlayer2Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDUpperformObjects1Objects = Hashtable.newFrom({"Upperform": gdjs.P2GameCode.GDUpperformObjects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player2": gdjs.P2GameCode.GDPlayer2Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDItem0Objects1Objects = Hashtable.newFrom({"Item0": gdjs.P2GameCode.GDItem0Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDExplosion1Objects1Objects = Hashtable.newFrom({"Explosion1": gdjs.P2GameCode.GDExplosion1Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player2": gdjs.P2GameCode.GDPlayer2Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDItem1Objects1Objects = Hashtable.newFrom({"Item1": gdjs.P2GameCode.GDItem1Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDExplosion1Objects1Objects = Hashtable.newFrom({"Explosion1": gdjs.P2GameCode.GDExplosion1Objects1});
gdjs.P2GameCode.asyncCallback12367924 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.P2GameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects2);

{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects2.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects2[i].getBehavior("PlatformerObject").setMaxSpeed(500);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects2.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects2[i].getBehavior("PlatformerObject").setAcceleration(2000);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects2.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects2[i].getBehavior("PlatformerObject").setDeceleration(2000);
}
}gdjs.P2GameCode.localVariables.length = 0;
}
gdjs.P2GameCode.eventsList10 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.P2GameCode.localVariables);
for (const obj of gdjs.P2GameCode.GDPlayer2Objects1) asyncObjectsList.addObject("Player2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.P2GameCode.asyncCallback12367924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player2": gdjs.P2GameCode.GDPlayer2Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDItem2Objects1Objects = Hashtable.newFrom({"Item2": gdjs.P2GameCode.GDItem2Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDExplosion1Objects1Objects = Hashtable.newFrom({"Explosion1": gdjs.P2GameCode.GDExplosion1Objects1});
gdjs.P2GameCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() < 1);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(1);
}}

}


};gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player2": gdjs.P2GameCode.GDPlayer2Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDItem3Objects1Objects = Hashtable.newFrom({"Item3": gdjs.P2GameCode.GDItem3Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDExplosion1Objects1Objects = Hashtable.newFrom({"Explosion1": gdjs.P2GameCode.GDExplosion1Objects1});
gdjs.P2GameCode.asyncCallback14465148 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.P2GameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects2);

{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects2.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects2[i].getBehavior("PlatformerObject").setMaxSpeed(500);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects2.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects2[i].getBehavior("PlatformerObject").setAcceleration(2000);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects2.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects2[i].getBehavior("PlatformerObject").setDeceleration(2000);
}
}gdjs.P2GameCode.localVariables.length = 0;
}
gdjs.P2GameCode.eventsList12 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.P2GameCode.localVariables);
for (const obj of gdjs.P2GameCode.GDPlayer2Objects1) asyncObjectsList.addObject("Player2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.P2GameCode.asyncCallback14465148(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform0Objects1ObjectsGDgdjs_9546P2GameCode_9546GDPlatform1Objects1ObjectsGDgdjs_9546P2GameCode_9546GDPlatform2Objects1ObjectsGDgdjs_9546P2GameCode_9546GDPlatform3Objects1ObjectsGDgdjs_9546P2GameCode_9546GDPlatform4Objects1Objects = Hashtable.newFrom({"Platform0": gdjs.P2GameCode.GDPlatform0Objects1, "Platform1": gdjs.P2GameCode.GDPlatform1Objects1, "Platform2": gdjs.P2GameCode.GDPlatform2Objects1, "Platform3": gdjs.P2GameCode.GDPlatform3Objects1, "Platform4": gdjs.P2GameCode.GDPlatform4Objects1});
gdjs.P2GameCode.eventsList13 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.P2GameCode.GDPlatform2Objects1, gdjs.P2GameCode.GDPlatform2Objects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDPlatform2Objects2.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDPlatform2Objects2[i].getX() > 770 ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDPlatform2Objects2[k] = gdjs.P2GameCode.GDPlatform2Objects2[i];
        ++k;
    }
}
gdjs.P2GameCode.GDPlatform2Objects2.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(-(1));
}}

}


{

/* Reuse gdjs.P2GameCode.GDPlatform2Objects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDPlatform2Objects1.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDPlatform2Objects1[i].getX() < 16 ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDPlatform2Objects1[k] = gdjs.P2GameCode.GDPlatform2Objects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDPlatform2Objects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(1);
}}

}


};gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDItem0Objects1ObjectsGDgdjs_9546P2GameCode_9546GDItem1Objects1ObjectsGDgdjs_9546P2GameCode_9546GDItem2Objects1ObjectsGDgdjs_9546P2GameCode_9546GDItem3Objects1Objects = Hashtable.newFrom({"Item0": gdjs.P2GameCode.GDItem0Objects1, "Item1": gdjs.P2GameCode.GDItem1Objects1, "Item2": gdjs.P2GameCode.GDItem2Objects1, "Item3": gdjs.P2GameCode.GDItem3Objects1});
gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform0Objects1ObjectsGDgdjs_9546P2GameCode_9546GDPlatform1Objects1ObjectsGDgdjs_9546P2GameCode_9546GDPlatform2Objects1ObjectsGDgdjs_9546P2GameCode_9546GDPlatform3Objects1ObjectsGDgdjs_9546P2GameCode_9546GDPlatform4Objects1Objects = Hashtable.newFrom({"Platform0": gdjs.P2GameCode.GDPlatform0Objects1, "Platform1": gdjs.P2GameCode.GDPlatform1Objects1, "Platform2": gdjs.P2GameCode.GDPlatform2Objects1, "Platform3": gdjs.P2GameCode.GDPlatform3Objects1, "Platform4": gdjs.P2GameCode.GDPlatform4Objects1});
gdjs.P2GameCode.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects1);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Timer");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "PlatformTime");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "LevelTime");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "HPTime");
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(600);
}{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(20);
}{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(20);
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(20);
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(20);
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects1[i].getBehavior("PlatformerObject").setAcceleration(2000);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects1[i].getBehavior("PlatformerObject").setDeceleration(2000);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects1[i].getBehavior("PlatformerObject").setMaxSpeed(500);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").setAcceleration(2000);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").setDeceleration(2000);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").setMaxSpeed(500);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreenFlatBar"), gdjs.P2GameCode.GDGreenFlatBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("OrangeFlatBar"), gdjs.P2GameCode.GDOrangeFlatBarObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDGreenFlatBarObjects1.length;i<l;++i) {
    if ( !(gdjs.P2GameCode.GDGreenFlatBarObjects1[i].IsEmpty((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDGreenFlatBarObjects1[k] = gdjs.P2GameCode.GDGreenFlatBarObjects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDGreenFlatBarObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDOrangeFlatBarObjects1.length;i<l;++i) {
    if ( !(gdjs.P2GameCode.GDOrangeFlatBarObjects1[i].IsEmpty((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDOrangeFlatBarObjects1[k] = gdjs.P2GameCode.GDOrangeFlatBarObjects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDOrangeFlatBarObjects1.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TImeUI"), gdjs.P2GameCode.GDTImeUIObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(Math.ceil(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "Timer")));
}{for(var i = 0, len = gdjs.P2GameCode.GDTImeUIObjects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDTImeUIObjects1[i].getBehavior("Text").setText("Time:" + gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber()));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("P1score"), gdjs.P2GameCode.GDP1scoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("P2score"), gdjs.P2GameCode.GDP2scoreObjects1);
{for(var i = 0, len = gdjs.P2GameCode.GDP1scoreObjects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDP1scoreObjects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(9).getAsString());
}
}{for(var i = 0, len = gdjs.P2GameCode.GDP2scoreObjects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDP2scoreObjects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(10).getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("GreenFlatBar"), gdjs.P2GameCode.GDGreenFlatBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("OrangeFlatBar"), gdjs.P2GameCode.GDOrangeFlatBarObjects1);
{for(var i = 0, len = gdjs.P2GameCode.GDGreenFlatBarObjects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDGreenFlatBarObjects1[i].SetValue(runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.P2GameCode.GDOrangeFlatBarObjects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDOrangeFlatBarObjects1[i].SetValue(runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.P2GameCode.GDGreenFlatBarObjects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDGreenFlatBarObjects1[i].SetMaxValue(runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.P2GameCode.GDOrangeFlatBarObjects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDOrangeFlatBarObjects1[i].SetMaxValue(runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.P2GameCode.GDGreenFlatBarObjects1.length = 0;

gdjs.P2GameCode.GDOrangeFlatBarObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.P2GameCode.GDGreenFlatBarObjects1_1final.length = 0;
gdjs.P2GameCode.GDOrangeFlatBarObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("OrangeFlatBar"), gdjs.P2GameCode.GDOrangeFlatBarObjects2);
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDOrangeFlatBarObjects2.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDOrangeFlatBarObjects2[i].IsEmpty((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.P2GameCode.GDOrangeFlatBarObjects2[k] = gdjs.P2GameCode.GDOrangeFlatBarObjects2[i];
        ++k;
    }
}
gdjs.P2GameCode.GDOrangeFlatBarObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.P2GameCode.GDOrangeFlatBarObjects2.length; j < jLen ; ++j) {
        if ( gdjs.P2GameCode.GDOrangeFlatBarObjects1_1final.indexOf(gdjs.P2GameCode.GDOrangeFlatBarObjects2[j]) === -1 )
            gdjs.P2GameCode.GDOrangeFlatBarObjects1_1final.push(gdjs.P2GameCode.GDOrangeFlatBarObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("GreenFlatBar"), gdjs.P2GameCode.GDGreenFlatBarObjects2);
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDGreenFlatBarObjects2.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDGreenFlatBarObjects2[i].IsEmpty((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.P2GameCode.GDGreenFlatBarObjects2[k] = gdjs.P2GameCode.GDGreenFlatBarObjects2[i];
        ++k;
    }
}
gdjs.P2GameCode.GDGreenFlatBarObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.P2GameCode.GDGreenFlatBarObjects2.length; j < jLen ; ++j) {
        if ( gdjs.P2GameCode.GDGreenFlatBarObjects1_1final.indexOf(gdjs.P2GameCode.GDGreenFlatBarObjects2[j]) === -1 )
            gdjs.P2GameCode.GDGreenFlatBarObjects1_1final.push(gdjs.P2GameCode.GDGreenFlatBarObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.P2GameCode.GDGreenFlatBarObjects1_1final, gdjs.P2GameCode.GDGreenFlatBarObjects1);
gdjs.copyArray(gdjs.P2GameCode.GDOrangeFlatBarObjects1_1final, gdjs.P2GameCode.GDOrangeFlatBarObjects1);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "Timer");
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "PlatformTime");
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "HPTime");
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "LevelTime");
}
{ //Subevents
gdjs.P2GameCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GreenFlatBar"), gdjs.P2GameCode.GDGreenFlatBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDPlayer1Objects1.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDPlayer1Objects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDPlayer1Objects1[k] = gdjs.P2GameCode.GDPlayer1Objects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDPlayer1Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDGreenFlatBarObjects1.length;i<l;++i) {
    if ( !(gdjs.P2GameCode.GDGreenFlatBarObjects1[i].IsEmpty((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDGreenFlatBarObjects1[k] = gdjs.P2GameCode.GDGreenFlatBarObjects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDGreenFlatBarObjects1.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.P2GameCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDPlayer1Objects1.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDPlayer1Objects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDPlayer1Objects1[k] = gdjs.P2GameCode.GDPlayer1Objects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDPlayer1Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDPlayer1Objects1 */
{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects1[i].getBehavior("Flippable").flipX(true);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() >= runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber());
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber());
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDPlayer1Objects1.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDPlayer1Objects1[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDPlayer1Objects1[k] = gdjs.P2GameCode.GDPlayer1Objects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDPlayer1Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDPlayer1Objects1 */
{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects1[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform0"), gdjs.P2GameCode.GDPlatform0Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects, "PlatformerObject", gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform0Objects1Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14454396);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(4).add(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform1"), gdjs.P2GameCode.GDPlatform1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects, "PlatformerObject", gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform1Objects1Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14455348);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(4).sub(5);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform2"), gdjs.P2GameCode.GDPlatform2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects, "PlatformerObject", gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform2Objects1Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14456116);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(4).add(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform3"), gdjs.P2GameCode.GDPlatform3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects, "PlatformerObject", gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform3Objects1Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14457028);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDPlatform3Objects1 */
{runtimeScene.getGame().getVariables().getFromIndex(4).add(1);
}{for(var i = 0, len = gdjs.P2GameCode.GDPlatform3Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlatform3Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform4"), gdjs.P2GameCode.GDPlatform4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects, "PlatformerObject", gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform4Objects1Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14458044);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDPlayer1Objects1 */
{runtimeScene.getGame().getVariables().getFromIndex(4).add(1);
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects1[i].getBehavior("PlatformerObject").setJumpSpeed(515);
}
}
{ //Subevents
gdjs.P2GameCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Upperform"), gdjs.P2GameCode.GDUpperformObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects, gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDUpperformObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14460028);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDPlayer1Objects1 */
{runtimeScene.getGame().getVariables().getFromIndex(4).sub(5);
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects1[i].setY(gdjs.P2GameCode.GDPlayer1Objects1[i].getY() + (50));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Item0"), gdjs.P2GameCode.GDItem0Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects, gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDItem0Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14461052);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDItem0Objects1 */
gdjs.P2GameCode.GDExplosion1Objects1.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(4).add(5);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDExplosion1Objects1Objects, (( gdjs.P2GameCode.GDItem0Objects1.length === 0 ) ? 0 :gdjs.P2GameCode.GDItem0Objects1[0].getPointX("")), (( gdjs.P2GameCode.GDItem0Objects1.length === 0 ) ? 0 :gdjs.P2GameCode.GDItem0Objects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.P2GameCode.GDExplosion1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDExplosion1Objects1[i].setParticleColor1("88;255;8");
}
}{for(var i = 0, len = gdjs.P2GameCode.GDItem0Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem0Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Item1"), gdjs.P2GameCode.GDItem1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects, gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDItem1Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14462404);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDItem1Objects1 */
/* Reuse gdjs.P2GameCode.GDPlayer1Objects1 */
gdjs.P2GameCode.GDExplosion1Objects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDExplosion1Objects1Objects, (( gdjs.P2GameCode.GDItem1Objects1.length === 0 ) ? 0 :gdjs.P2GameCode.GDItem1Objects1[0].getPointX("")), (( gdjs.P2GameCode.GDItem1Objects1.length === 0 ) ? 0 :gdjs.P2GameCode.GDItem1Objects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.P2GameCode.GDExplosion1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDExplosion1Objects1[i].setParticleColor1("88;255;8");
}
}{for(var i = 0, len = gdjs.P2GameCode.GDItem1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem1Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects1[i].getBehavior("PlatformerObject").setMaxSpeed(750);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects1[i].getBehavior("PlatformerObject").setAcceleration(2500);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects1[i].getBehavior("PlatformerObject").setDeceleration(2500);
}
}
{ //Subevents
gdjs.P2GameCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Item2"), gdjs.P2GameCode.GDItem2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects, gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDItem2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14224220);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDItem2Objects1 */
gdjs.P2GameCode.GDExplosion1Objects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDExplosion1Objects1Objects, (( gdjs.P2GameCode.GDItem2Objects1.length === 0 ) ? 0 :gdjs.P2GameCode.GDItem2Objects1[0].getPointX("")), (( gdjs.P2GameCode.GDItem2Objects1.length === 0 ) ? 0 :gdjs.P2GameCode.GDItem2Objects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.P2GameCode.GDExplosion1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDExplosion1Objects1[i].setParticleColor1("88;255;8");
}
}{for(var i = 0, len = gdjs.P2GameCode.GDItem2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem2Objects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).sub(5);
}
{ //Subevents
gdjs.P2GameCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Item3"), gdjs.P2GameCode.GDItem3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer1Objects1Objects, gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDItem3Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14464212);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDItem3Objects1 */
/* Reuse gdjs.P2GameCode.GDPlayer1Objects1 */
gdjs.P2GameCode.GDExplosion1Objects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDExplosion1Objects1Objects, (( gdjs.P2GameCode.GDItem3Objects1.length === 0 ) ? 0 :gdjs.P2GameCode.GDItem3Objects1[0].getPointX("")), (( gdjs.P2GameCode.GDItem3Objects1.length === 0 ) ? 0 :gdjs.P2GameCode.GDItem3Objects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.P2GameCode.GDExplosion1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDExplosion1Objects1[i].setParticleColor1("88;255;8");
}
}{for(var i = 0, len = gdjs.P2GameCode.GDItem3Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem3Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects1[i].getBehavior("PlatformerObject").setMaxSpeed(0);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects1[i].getBehavior("PlatformerObject").setAcceleration(0);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer1Objects1[i].getBehavior("PlatformerObject").setDeceleration(0);
}
}
{ //Subevents
gdjs.P2GameCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.P2GameCode.GDPlayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDPlayer1Objects1.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDPlayer1Objects1[i].getY() > 725 ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDPlayer1Objects1[k] = gdjs.P2GameCode.GDPlayer1Objects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDPlayer1Objects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(0);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects1);
{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("Flippable").flipX(true);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects1);
{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreenFlatBar"), gdjs.P2GameCode.GDGreenFlatBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDPlayer2Objects1.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDPlayer2Objects1[k] = gdjs.P2GameCode.GDPlayer2Objects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDPlayer2Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDGreenFlatBarObjects1.length;i<l;++i) {
    if ( !(gdjs.P2GameCode.GDGreenFlatBarObjects1[i].IsEmpty((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDGreenFlatBarObjects1[k] = gdjs.P2GameCode.GDGreenFlatBarObjects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDGreenFlatBarObjects1.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.P2GameCode.eventsList8(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber() >= runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber());
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber());
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform0"), gdjs.P2GameCode.GDPlatform0Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects, "PlatformerObject", gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform0Objects1Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14471828);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(5).add(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform1"), gdjs.P2GameCode.GDPlatform1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects, "PlatformerObject", gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform1Objects1Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14472740);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(5).sub(5);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform2"), gdjs.P2GameCode.GDPlatform2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects, "PlatformerObject", gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform2Objects1Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14473652);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(5).add(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform3"), gdjs.P2GameCode.GDPlatform3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects, "PlatformerObject", gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform3Objects1Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14474564);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDPlatform3Objects1 */
{runtimeScene.getGame().getVariables().getFromIndex(5).add(1);
}{for(var i = 0, len = gdjs.P2GameCode.GDPlatform3Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlatform3Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform4"), gdjs.P2GameCode.GDPlatform4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects, "PlatformerObject", gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform4Objects1Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14475620);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDPlayer2Objects1 */
{runtimeScene.getGame().getVariables().getFromIndex(5).add(1);
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").setJumpSpeed(515);
}
}
{ //Subevents
gdjs.P2GameCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Upperform"), gdjs.P2GameCode.GDUpperformObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects, gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDUpperformObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14477532);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDPlayer2Objects1 */
{runtimeScene.getGame().getVariables().getFromIndex(5).sub(5);
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects1[i].setY(gdjs.P2GameCode.GDPlayer2Objects1[i].getY() + (50));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Item0"), gdjs.P2GameCode.GDItem0Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects, gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDItem0Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14478268);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDItem0Objects1 */
gdjs.P2GameCode.GDExplosion1Objects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDExplosion1Objects1Objects, (( gdjs.P2GameCode.GDItem0Objects1.length === 0 ) ? 0 :gdjs.P2GameCode.GDItem0Objects1[0].getPointX("")), (( gdjs.P2GameCode.GDItem0Objects1.length === 0 ) ? 0 :gdjs.P2GameCode.GDItem0Objects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.P2GameCode.GDExplosion1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDExplosion1Objects1[i].setParticleColor1("255;160;0");
}
}{runtimeScene.getGame().getVariables().getFromIndex(5).add(5);
}{for(var i = 0, len = gdjs.P2GameCode.GDItem0Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem0Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Item1"), gdjs.P2GameCode.GDItem1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects, gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDItem1Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14460764);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDItem1Objects1 */
/* Reuse gdjs.P2GameCode.GDPlayer2Objects1 */
gdjs.P2GameCode.GDExplosion1Objects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDExplosion1Objects1Objects, (( gdjs.P2GameCode.GDItem1Objects1.length === 0 ) ? 0 :gdjs.P2GameCode.GDItem1Objects1[0].getPointX("")), (( gdjs.P2GameCode.GDItem1Objects1.length === 0 ) ? 0 :gdjs.P2GameCode.GDItem1Objects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.P2GameCode.GDExplosion1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDExplosion1Objects1[i].setParticleColor1("255;160;0");
}
}{for(var i = 0, len = gdjs.P2GameCode.GDItem1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem1Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").setMaxSpeed(750);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").setAcceleration(2500);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").setDeceleration(2500);
}
}
{ //Subevents
gdjs.P2GameCode.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Item2"), gdjs.P2GameCode.GDItem2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects, gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDItem2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14482012);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDItem2Objects1 */
gdjs.P2GameCode.GDExplosion1Objects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDExplosion1Objects1Objects, (( gdjs.P2GameCode.GDItem2Objects1.length === 0 ) ? 0 :gdjs.P2GameCode.GDItem2Objects1[0].getPointX("")), (( gdjs.P2GameCode.GDItem2Objects1.length === 0 ) ? 0 :gdjs.P2GameCode.GDItem2Objects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.P2GameCode.GDExplosion1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDExplosion1Objects1[i].setParticleColor1("255;160;0");
}
}{for(var i = 0, len = gdjs.P2GameCode.GDItem2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem2Objects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).sub(5);
}
{ //Subevents
gdjs.P2GameCode.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Item3"), gdjs.P2GameCode.GDItem3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlayer2Objects1Objects, gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDItem3Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12564196);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDItem3Objects1 */
/* Reuse gdjs.P2GameCode.GDPlayer2Objects1 */
gdjs.P2GameCode.GDExplosion1Objects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDExplosion1Objects1Objects, (( gdjs.P2GameCode.GDItem3Objects1.length === 0 ) ? 0 :gdjs.P2GameCode.GDItem3Objects1[0].getPointX("")), (( gdjs.P2GameCode.GDItem3Objects1.length === 0 ) ? 0 :gdjs.P2GameCode.GDItem3Objects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.P2GameCode.GDExplosion1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDExplosion1Objects1[i].setParticleColor1("255;160;0");
}
}{for(var i = 0, len = gdjs.P2GameCode.GDItem3Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem3Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").setMaxSpeed(0);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").setAcceleration(0);
}
}{for(var i = 0, len = gdjs.P2GameCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlayer2Objects1[i].getBehavior("PlatformerObject").setDeceleration(0);
}
}
{ //Subevents
gdjs.P2GameCode.eventsList12(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.P2GameCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDPlayer2Objects1.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDPlayer2Objects1[i].getY() > 725 ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDPlayer2Objects1[k] = gdjs.P2GameCode.GDPlayer2Objects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDPlayer2Objects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(0);
}}

}


{



}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Item0"), gdjs.P2GameCode.GDItem0Objects1);
gdjs.copyArray(runtimeScene.getObjects("Item1"), gdjs.P2GameCode.GDItem1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Item2"), gdjs.P2GameCode.GDItem2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Item3"), gdjs.P2GameCode.GDItem3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Platform0"), gdjs.P2GameCode.GDPlatform0Objects1);
gdjs.copyArray(runtimeScene.getObjects("Platform1"), gdjs.P2GameCode.GDPlatform1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Platform2"), gdjs.P2GameCode.GDPlatform2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Platform3"), gdjs.P2GameCode.GDPlatform3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Platform4"), gdjs.P2GameCode.GDPlatform4Objects1);
{for(var i = 0, len = gdjs.P2GameCode.GDPlatform0Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlatform0Objects1[i].setY(gdjs.P2GameCode.GDPlatform0Objects1[i].getY() - (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber()));
}
for(var i = 0, len = gdjs.P2GameCode.GDPlatform1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlatform1Objects1[i].setY(gdjs.P2GameCode.GDPlatform1Objects1[i].getY() - (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber()));
}
for(var i = 0, len = gdjs.P2GameCode.GDPlatform2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlatform2Objects1[i].setY(gdjs.P2GameCode.GDPlatform2Objects1[i].getY() - (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber()));
}
for(var i = 0, len = gdjs.P2GameCode.GDPlatform3Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlatform3Objects1[i].setY(gdjs.P2GameCode.GDPlatform3Objects1[i].getY() - (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber()));
}
for(var i = 0, len = gdjs.P2GameCode.GDPlatform4Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlatform4Objects1[i].setY(gdjs.P2GameCode.GDPlatform4Objects1[i].getY() - (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber()));
}
}{for(var i = 0, len = gdjs.P2GameCode.GDItem0Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem0Objects1[i].setY(gdjs.P2GameCode.GDItem0Objects1[i].getY() - (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber()));
}
for(var i = 0, len = gdjs.P2GameCode.GDItem1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem1Objects1[i].setY(gdjs.P2GameCode.GDItem1Objects1[i].getY() - (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber()));
}
for(var i = 0, len = gdjs.P2GameCode.GDItem2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem2Objects1[i].setY(gdjs.P2GameCode.GDItem2Objects1[i].getY() - (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber()));
}
for(var i = 0, len = gdjs.P2GameCode.GDItem3Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem3Objects1[i].setY(gdjs.P2GameCode.GDItem3Objects1[i].getY() - (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "PlatformTime", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.P2GameCode.GDPlatform0Objects1.length = 0;

gdjs.P2GameCode.GDPlatform1Objects1.length = 0;

gdjs.P2GameCode.GDPlatform2Objects1.length = 0;

gdjs.P2GameCode.GDPlatform3Objects1.length = 0;

gdjs.P2GameCode.GDPlatform4Objects1.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform0Objects1ObjectsGDgdjs_9546P2GameCode_9546GDPlatform1Objects1ObjectsGDgdjs_9546P2GameCode_9546GDPlatform2Objects1ObjectsGDgdjs_9546P2GameCode_9546GDPlatform3Objects1ObjectsGDgdjs_9546P2GameCode_9546GDPlatform4Objects1Objects, "Platform" + gdjs.evtTools.common.toString(gdjs.randomInRange(0, 4)), gdjs.randomInRange(17, 769), runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber(), "");
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(100);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Platform2"), gdjs.P2GameCode.GDPlatform2Objects1);
{for(var i = 0, len = gdjs.P2GameCode.GDPlatform2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlatform2Objects1[i].setX(gdjs.P2GameCode.GDPlatform2Objects1[i].getX() + (runtimeScene.getGame().getVariables().getFromIndex(7).getAsNumber() * runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber()));
}
}
{ //Subevents
gdjs.P2GameCode.eventsList13(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "HPTime", 4, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14488900);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Platform0"), gdjs.P2GameCode.GDPlatform0Objects1);
gdjs.copyArray(runtimeScene.getObjects("Platform1"), gdjs.P2GameCode.GDPlatform1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Platform2"), gdjs.P2GameCode.GDPlatform2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Platform3"), gdjs.P2GameCode.GDPlatform3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Platform4"), gdjs.P2GameCode.GDPlatform4Objects1);
gdjs.P2GameCode.GDItem0Objects1.length = 0;

gdjs.P2GameCode.GDItem1Objects1.length = 0;

gdjs.P2GameCode.GDItem2Objects1.length = 0;

gdjs.P2GameCode.GDItem3Objects1.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDItem0Objects1ObjectsGDgdjs_9546P2GameCode_9546GDItem1Objects1ObjectsGDgdjs_9546P2GameCode_9546GDItem2Objects1ObjectsGDgdjs_9546P2GameCode_9546GDItem3Objects1Objects, "Item" + gdjs.evtTools.common.toString(gdjs.randomInRange(0, 3)), 0, 0, "");
}{gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.P2GameCode.mapOfGDgdjs_9546P2GameCode_9546GDPlatform0Objects1ObjectsGDgdjs_9546P2GameCode_9546GDPlatform1Objects1ObjectsGDgdjs_9546P2GameCode_9546GDPlatform2Objects1ObjectsGDgdjs_9546P2GameCode_9546GDPlatform3Objects1ObjectsGDgdjs_9546P2GameCode_9546GDPlatform4Objects1Objects);
}{for(var i = 0, len = gdjs.P2GameCode.GDItem0Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem0Objects1[i].putAroundObject((gdjs.P2GameCode.GDPlatform0Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform0Objects1[0] : (gdjs.P2GameCode.GDPlatform1Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform1Objects1[0] : (gdjs.P2GameCode.GDPlatform2Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform2Objects1[0] : (gdjs.P2GameCode.GDPlatform3Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform3Objects1[0] : (gdjs.P2GameCode.GDPlatform4Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform4Objects1[0] : null))))), 25, -(90));
}
for(var i = 0, len = gdjs.P2GameCode.GDItem1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem1Objects1[i].putAroundObject((gdjs.P2GameCode.GDPlatform0Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform0Objects1[0] : (gdjs.P2GameCode.GDPlatform1Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform1Objects1[0] : (gdjs.P2GameCode.GDPlatform2Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform2Objects1[0] : (gdjs.P2GameCode.GDPlatform3Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform3Objects1[0] : (gdjs.P2GameCode.GDPlatform4Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform4Objects1[0] : null))))), 25, -(90));
}
for(var i = 0, len = gdjs.P2GameCode.GDItem2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem2Objects1[i].putAroundObject((gdjs.P2GameCode.GDPlatform0Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform0Objects1[0] : (gdjs.P2GameCode.GDPlatform1Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform1Objects1[0] : (gdjs.P2GameCode.GDPlatform2Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform2Objects1[0] : (gdjs.P2GameCode.GDPlatform3Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform3Objects1[0] : (gdjs.P2GameCode.GDPlatform4Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform4Objects1[0] : null))))), 25, -(90));
}
for(var i = 0, len = gdjs.P2GameCode.GDItem3Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem3Objects1[i].putAroundObject((gdjs.P2GameCode.GDPlatform0Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform0Objects1[0] : (gdjs.P2GameCode.GDPlatform1Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform1Objects1[0] : (gdjs.P2GameCode.GDPlatform2Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform2Objects1[0] : (gdjs.P2GameCode.GDPlatform3Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform3Objects1[0] : (gdjs.P2GameCode.GDPlatform4Objects1.length !== 0 ? gdjs.P2GameCode.GDPlatform4Objects1[0] : null))))), 25, -(90));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "LevelTime", 20, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14489868);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(6).add(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform0"), gdjs.P2GameCode.GDPlatform0Objects1);
gdjs.copyArray(runtimeScene.getObjects("Platform1"), gdjs.P2GameCode.GDPlatform1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Platform2"), gdjs.P2GameCode.GDPlatform2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Platform3"), gdjs.P2GameCode.GDPlatform3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Platform4"), gdjs.P2GameCode.GDPlatform4Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDPlatform0Objects1.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDPlatform0Objects1[i].getY() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDPlatform0Objects1[k] = gdjs.P2GameCode.GDPlatform0Objects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDPlatform0Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDPlatform1Objects1.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDPlatform1Objects1[i].getY() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDPlatform1Objects1[k] = gdjs.P2GameCode.GDPlatform1Objects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDPlatform1Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDPlatform2Objects1.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDPlatform2Objects1[i].getY() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDPlatform2Objects1[k] = gdjs.P2GameCode.GDPlatform2Objects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDPlatform2Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDPlatform3Objects1.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDPlatform3Objects1[i].getY() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDPlatform3Objects1[k] = gdjs.P2GameCode.GDPlatform3Objects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDPlatform3Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDPlatform4Objects1.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDPlatform4Objects1[i].getY() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDPlatform4Objects1[k] = gdjs.P2GameCode.GDPlatform4Objects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDPlatform4Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDPlatform0Objects1 */
/* Reuse gdjs.P2GameCode.GDPlatform1Objects1 */
/* Reuse gdjs.P2GameCode.GDPlatform2Objects1 */
/* Reuse gdjs.P2GameCode.GDPlatform3Objects1 */
/* Reuse gdjs.P2GameCode.GDPlatform4Objects1 */
{for(var i = 0, len = gdjs.P2GameCode.GDPlatform0Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlatform0Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.P2GameCode.GDPlatform1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlatform1Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.P2GameCode.GDPlatform2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlatform2Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.P2GameCode.GDPlatform3Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlatform3Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.P2GameCode.GDPlatform4Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDPlatform4Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Item0"), gdjs.P2GameCode.GDItem0Objects1);
gdjs.copyArray(runtimeScene.getObjects("Item1"), gdjs.P2GameCode.GDItem1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Item2"), gdjs.P2GameCode.GDItem2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Item3"), gdjs.P2GameCode.GDItem3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDItem0Objects1.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDItem0Objects1[i].getY() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDItem0Objects1[k] = gdjs.P2GameCode.GDItem0Objects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDItem0Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDItem1Objects1.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDItem1Objects1[i].getY() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDItem1Objects1[k] = gdjs.P2GameCode.GDItem1Objects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDItem1Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDItem2Objects1.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDItem2Objects1[i].getY() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDItem2Objects1[k] = gdjs.P2GameCode.GDItem2Objects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDItem2Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.P2GameCode.GDItem3Objects1.length;i<l;++i) {
    if ( gdjs.P2GameCode.GDItem3Objects1[i].getY() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.P2GameCode.GDItem3Objects1[k] = gdjs.P2GameCode.GDItem3Objects1[i];
        ++k;
    }
}
gdjs.P2GameCode.GDItem3Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.P2GameCode.GDItem0Objects1 */
/* Reuse gdjs.P2GameCode.GDItem1Objects1 */
/* Reuse gdjs.P2GameCode.GDItem2Objects1 */
/* Reuse gdjs.P2GameCode.GDItem3Objects1 */
{for(var i = 0, len = gdjs.P2GameCode.GDItem0Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem0Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.P2GameCode.GDItem1Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem1Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.P2GameCode.GDItem2Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem2Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.P2GameCode.GDItem3Objects1.length ;i < len;++i) {
    gdjs.P2GameCode.GDItem3Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


};

gdjs.P2GameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.P2GameCode.GDPlayer1Objects1.length = 0;
gdjs.P2GameCode.GDPlayer1Objects2.length = 0;
gdjs.P2GameCode.GDPlayer1Objects3.length = 0;
gdjs.P2GameCode.GDPlatform0Objects1.length = 0;
gdjs.P2GameCode.GDPlatform0Objects2.length = 0;
gdjs.P2GameCode.GDPlatform0Objects3.length = 0;
gdjs.P2GameCode.GDSideObjects1.length = 0;
gdjs.P2GameCode.GDSideObjects2.length = 0;
gdjs.P2GameCode.GDSideObjects3.length = 0;
gdjs.P2GameCode.GDPlatform1Objects1.length = 0;
gdjs.P2GameCode.GDPlatform1Objects2.length = 0;
gdjs.P2GameCode.GDPlatform1Objects3.length = 0;
gdjs.P2GameCode.GDTImeUIObjects1.length = 0;
gdjs.P2GameCode.GDTImeUIObjects2.length = 0;
gdjs.P2GameCode.GDTImeUIObjects3.length = 0;
gdjs.P2GameCode.GDSpeedObjects1.length = 0;
gdjs.P2GameCode.GDSpeedObjects2.length = 0;
gdjs.P2GameCode.GDSpeedObjects3.length = 0;
gdjs.P2GameCode.GDGreenFlatBarObjects1.length = 0;
gdjs.P2GameCode.GDGreenFlatBarObjects2.length = 0;
gdjs.P2GameCode.GDGreenFlatBarObjects3.length = 0;
gdjs.P2GameCode.GD_95951PsHPObjects1.length = 0;
gdjs.P2GameCode.GD_95951PsHPObjects2.length = 0;
gdjs.P2GameCode.GD_95951PsHPObjects3.length = 0;
gdjs.P2GameCode.GDOrangeFlatBarObjects1.length = 0;
gdjs.P2GameCode.GDOrangeFlatBarObjects2.length = 0;
gdjs.P2GameCode.GDOrangeFlatBarObjects3.length = 0;
gdjs.P2GameCode.GDUpperformObjects1.length = 0;
gdjs.P2GameCode.GDUpperformObjects2.length = 0;
gdjs.P2GameCode.GDUpperformObjects3.length = 0;
gdjs.P2GameCode.GDItem0Objects1.length = 0;
gdjs.P2GameCode.GDItem0Objects2.length = 0;
gdjs.P2GameCode.GDItem0Objects3.length = 0;
gdjs.P2GameCode.GDExplosion1Objects1.length = 0;
gdjs.P2GameCode.GDExplosion1Objects2.length = 0;
gdjs.P2GameCode.GDExplosion1Objects3.length = 0;
gdjs.P2GameCode.GDPlatform2Objects1.length = 0;
gdjs.P2GameCode.GDPlatform2Objects2.length = 0;
gdjs.P2GameCode.GDPlatform2Objects3.length = 0;
gdjs.P2GameCode.GDPlatform3Objects1.length = 0;
gdjs.P2GameCode.GDPlatform3Objects2.length = 0;
gdjs.P2GameCode.GDPlatform3Objects3.length = 0;
gdjs.P2GameCode.GDPlayer2Objects1.length = 0;
gdjs.P2GameCode.GDPlayer2Objects2.length = 0;
gdjs.P2GameCode.GDPlayer2Objects3.length = 0;
gdjs.P2GameCode.GD_95952PsHPObjects1.length = 0;
gdjs.P2GameCode.GD_95952PsHPObjects2.length = 0;
gdjs.P2GameCode.GD_95952PsHPObjects3.length = 0;
gdjs.P2GameCode.GDScore2Objects1.length = 0;
gdjs.P2GameCode.GDScore2Objects2.length = 0;
gdjs.P2GameCode.GDScore2Objects3.length = 0;
gdjs.P2GameCode.GDScore1Objects1.length = 0;
gdjs.P2GameCode.GDScore1Objects2.length = 0;
gdjs.P2GameCode.GDScore1Objects3.length = 0;
gdjs.P2GameCode.GDP1scoreObjects1.length = 0;
gdjs.P2GameCode.GDP1scoreObjects2.length = 0;
gdjs.P2GameCode.GDP1scoreObjects3.length = 0;
gdjs.P2GameCode.GDP2scoreObjects1.length = 0;
gdjs.P2GameCode.GDP2scoreObjects2.length = 0;
gdjs.P2GameCode.GDP2scoreObjects3.length = 0;
gdjs.P2GameCode.GDPlatform4Objects1.length = 0;
gdjs.P2GameCode.GDPlatform4Objects2.length = 0;
gdjs.P2GameCode.GDPlatform4Objects3.length = 0;
gdjs.P2GameCode.GDItem1Objects1.length = 0;
gdjs.P2GameCode.GDItem1Objects2.length = 0;
gdjs.P2GameCode.GDItem1Objects3.length = 0;
gdjs.P2GameCode.GDItem2Objects1.length = 0;
gdjs.P2GameCode.GDItem2Objects2.length = 0;
gdjs.P2GameCode.GDItem2Objects3.length = 0;
gdjs.P2GameCode.GDItem3Objects1.length = 0;
gdjs.P2GameCode.GDItem3Objects2.length = 0;
gdjs.P2GameCode.GDItem3Objects3.length = 0;
gdjs.P2GameCode.GDBackgroundObjects1.length = 0;
gdjs.P2GameCode.GDBackgroundObjects2.length = 0;
gdjs.P2GameCode.GDBackgroundObjects3.length = 0;

gdjs.P2GameCode.eventsList14(runtimeScene);
gdjs.P2GameCode.GDPlayer1Objects1.length = 0;
gdjs.P2GameCode.GDPlayer1Objects2.length = 0;
gdjs.P2GameCode.GDPlayer1Objects3.length = 0;
gdjs.P2GameCode.GDPlatform0Objects1.length = 0;
gdjs.P2GameCode.GDPlatform0Objects2.length = 0;
gdjs.P2GameCode.GDPlatform0Objects3.length = 0;
gdjs.P2GameCode.GDSideObjects1.length = 0;
gdjs.P2GameCode.GDSideObjects2.length = 0;
gdjs.P2GameCode.GDSideObjects3.length = 0;
gdjs.P2GameCode.GDPlatform1Objects1.length = 0;
gdjs.P2GameCode.GDPlatform1Objects2.length = 0;
gdjs.P2GameCode.GDPlatform1Objects3.length = 0;
gdjs.P2GameCode.GDTImeUIObjects1.length = 0;
gdjs.P2GameCode.GDTImeUIObjects2.length = 0;
gdjs.P2GameCode.GDTImeUIObjects3.length = 0;
gdjs.P2GameCode.GDSpeedObjects1.length = 0;
gdjs.P2GameCode.GDSpeedObjects2.length = 0;
gdjs.P2GameCode.GDSpeedObjects3.length = 0;
gdjs.P2GameCode.GDGreenFlatBarObjects1.length = 0;
gdjs.P2GameCode.GDGreenFlatBarObjects2.length = 0;
gdjs.P2GameCode.GDGreenFlatBarObjects3.length = 0;
gdjs.P2GameCode.GD_95951PsHPObjects1.length = 0;
gdjs.P2GameCode.GD_95951PsHPObjects2.length = 0;
gdjs.P2GameCode.GD_95951PsHPObjects3.length = 0;
gdjs.P2GameCode.GDOrangeFlatBarObjects1.length = 0;
gdjs.P2GameCode.GDOrangeFlatBarObjects2.length = 0;
gdjs.P2GameCode.GDOrangeFlatBarObjects3.length = 0;
gdjs.P2GameCode.GDUpperformObjects1.length = 0;
gdjs.P2GameCode.GDUpperformObjects2.length = 0;
gdjs.P2GameCode.GDUpperformObjects3.length = 0;
gdjs.P2GameCode.GDItem0Objects1.length = 0;
gdjs.P2GameCode.GDItem0Objects2.length = 0;
gdjs.P2GameCode.GDItem0Objects3.length = 0;
gdjs.P2GameCode.GDExplosion1Objects1.length = 0;
gdjs.P2GameCode.GDExplosion1Objects2.length = 0;
gdjs.P2GameCode.GDExplosion1Objects3.length = 0;
gdjs.P2GameCode.GDPlatform2Objects1.length = 0;
gdjs.P2GameCode.GDPlatform2Objects2.length = 0;
gdjs.P2GameCode.GDPlatform2Objects3.length = 0;
gdjs.P2GameCode.GDPlatform3Objects1.length = 0;
gdjs.P2GameCode.GDPlatform3Objects2.length = 0;
gdjs.P2GameCode.GDPlatform3Objects3.length = 0;
gdjs.P2GameCode.GDPlayer2Objects1.length = 0;
gdjs.P2GameCode.GDPlayer2Objects2.length = 0;
gdjs.P2GameCode.GDPlayer2Objects3.length = 0;
gdjs.P2GameCode.GD_95952PsHPObjects1.length = 0;
gdjs.P2GameCode.GD_95952PsHPObjects2.length = 0;
gdjs.P2GameCode.GD_95952PsHPObjects3.length = 0;
gdjs.P2GameCode.GDScore2Objects1.length = 0;
gdjs.P2GameCode.GDScore2Objects2.length = 0;
gdjs.P2GameCode.GDScore2Objects3.length = 0;
gdjs.P2GameCode.GDScore1Objects1.length = 0;
gdjs.P2GameCode.GDScore1Objects2.length = 0;
gdjs.P2GameCode.GDScore1Objects3.length = 0;
gdjs.P2GameCode.GDP1scoreObjects1.length = 0;
gdjs.P2GameCode.GDP1scoreObjects2.length = 0;
gdjs.P2GameCode.GDP1scoreObjects3.length = 0;
gdjs.P2GameCode.GDP2scoreObjects1.length = 0;
gdjs.P2GameCode.GDP2scoreObjects2.length = 0;
gdjs.P2GameCode.GDP2scoreObjects3.length = 0;
gdjs.P2GameCode.GDPlatform4Objects1.length = 0;
gdjs.P2GameCode.GDPlatform4Objects2.length = 0;
gdjs.P2GameCode.GDPlatform4Objects3.length = 0;
gdjs.P2GameCode.GDItem1Objects1.length = 0;
gdjs.P2GameCode.GDItem1Objects2.length = 0;
gdjs.P2GameCode.GDItem1Objects3.length = 0;
gdjs.P2GameCode.GDItem2Objects1.length = 0;
gdjs.P2GameCode.GDItem2Objects2.length = 0;
gdjs.P2GameCode.GDItem2Objects3.length = 0;
gdjs.P2GameCode.GDItem3Objects1.length = 0;
gdjs.P2GameCode.GDItem3Objects2.length = 0;
gdjs.P2GameCode.GDItem3Objects3.length = 0;
gdjs.P2GameCode.GDBackgroundObjects1.length = 0;
gdjs.P2GameCode.GDBackgroundObjects2.length = 0;
gdjs.P2GameCode.GDBackgroundObjects3.length = 0;


return;

}

gdjs['P2GameCode'] = gdjs.P2GameCode;
